---
name: Enterprise Fleet Orchestrator
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#006398'
  on-secondary: '#ffffff'
  secondary-container: '#5bb8fe'
  on-secondary-container: '#00476e'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#23005c'
  on-tertiary-container: '#9466ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#cce5ff'
  secondary-fixed-dim: '#93ccff'
  on-secondary-fixed: '#001d31'
  on-secondary-fixed-variant: '#004b73'
  tertiary-fixed: '#e9ddff'
  tertiary-fixed-dim: '#d0bcff'
  on-tertiary-fixed: '#23005c'
  on-tertiary-fixed-variant: '#5516be'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display:
    fontFamily: IBM Plex Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-lg-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  tabular-data:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 20px
  label-lg:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system delivers a commanding, data-dense, mission-critical operational interface tailored specifically for high-throughput logistics, supply chain monitoring, and enterprise fleet dispatching. The emotional tone is authoritative, hyper-reliable, and serene under pressure. It prioritizes rapid optical parsing, rigorous structural discipline, and fatigue reduction for operators managing multi-screen control centers for extended shifts.

The aesthetic fuses modern enterprise functionalism with a precision instrument finish. While rooted in deep architectural structure, it eschews heavy visual clutter in favor of crisp boundaries, strict 4px alignment grids, intentional tabular spacing, and deliberate status luminescence. Every element adheres to an Arabic-first mental model: reading paths, logical progressions, chronological charts, numerical tables, and hierarchy flows operate natively from right to left (RTL) without feeling mirrored or retrofitted.

## Colors

The color architecture enforces clear informational hierarchy, keeping data-heavy views calm while elevating real-time states and operational alerts.

### Core Foundation
- **Canvas Base (`#F8FAFC`)**: A crisp, cool slate-white foundation that eliminates eye strain and delivers stark contrast against elevated surfaces.
- **Card Surface (`#FFFFFF`)**: Pure white reserved for modular containers, floating panes, and data grids.
- **Primary Brand / Slate Deep (`#0F172A`)**: Primary text, navigation chrome, table headers, and structural focal points. Its lighter counterpart (`#1E293B`) supports secondary visual grounding and deep surface hover states.
- **Secondary / Muted Teal & Slate Blue (`#0284C7` & `#0EA5E9`)**: Interactive accents, link states, active navigation indicators, and directional vectors.
- **Structural Outlines (`#E2E8F0`)**: Hairline borders separating functional zones without generating visual noise.

### Status Semantic Tokens
Status tokens feature dual-tier pairings—a crisp glyph/text shade matched with a soft, tinted background (10–12% opacity) for instant state scanning:
- **Active / On Track (`#10B981`)**: Soft emerald for moving vehicles, cleared waypoints, and completed cargo handoffs. Tint surface: `#ECFDF5`.
- **In Progress / Alert (`#F59E0B`)**: Warm amber for customs holds, route rerouting, maintenance flags, and fuel stops. Tint surface: `#FFFBEB`.
- **Delayed / Critical (`#EF4444`)**: Coral red for collisions, breakdown halts, severe route breaches, and safety triggers. Tint surface: `#FEF2F2`.
- **Review Needed / Attention (`#8B5CF6`)**: Soft violet for pending dispatch approvals, documentation anomalies, and driver shift reallocations. Tint surface: `#F5F3FF`.
- **Inactive / Muted (`#64748B`)**: Neutral slate grey for parked units, dry runs, and archived manifests. Tint surface: `#F1F5F9`.

## Typography

Typography in this design system is engineered specifically for the vertical rhythm, baseline alignment, and ligature demands of the Arabic script. The primary family is **IBM Plex Sans Arabic** (paired with IBM Plex Sans for Western alphanumeric cross-references and telemetry codes), delivering a structured, engineered balance suited for dense data grids.

### Font System & Fallbacks
- Primary: `IBM Plex Sans Arabic`, `Tajawal`, sans-serif.
- Western telemetry & system codes: `IBM Plex Sans`, monospace fallback.

### RTL Legibility Rules
- **Line Heights**: Arabic characters require 20–30% more vertical breathing room than Latin letterforms to prevent accents (*Harakat* and dots) from colliding across dense rows.
- **Tabular Numerals**: Numerical data across route lists, vehicle speeds, manifests, and timestamps must leverage `font-feature-settings: "tnum" 1` to ensure uniform column-width alignment.
- **Punctuation Alignment**: Trailing metric units (e.g., كم/س, كجم, د.إ) must maintain consistent right-to-left layout order without inline direction flipping.

## Layout & Spacing

The layout model is governed by an 8-point base grid (with a strict 4-point micro-subgrid for controls, metric chips, and table cells) calibrated to balance data density with visual clarity.

### Grid Architecture
- **Control Center Layout**: A hybrid fluid/fixed shell featuring an RTL dock navigation rail (fixed width 72px collapsed / 240px expanded) pinned to the right edge.
- **Data Workspaces**: 12-column dynamic fluid grid utilizing 1rem (`16px`) gutters on desktop screens, expanding to 1.5rem (`24px`) on ultra-wide ops displays (≥1920px).
- **Responsive Adaptations**:
  - **Desktop (1280px+)**: Multi-pane split screen with persistent contextual maps, sticky header tables, and slide-in telematics drawers.
  - **Tablet (768px – 1279px)**: Collapsible sidebar rail, stacked analytics widgets, horizontal scroll for tables with pinned right-hand identification columns.
  - **Mobile (< 768px)**: Single-column flow, bottom-docked utility actions, transformed table view into grouped RTL swipe cards.

## Elevation & Depth

Visual hierarchy uses crisp boundary surfaces rather than exaggerated vertical projection, preserving precision and preventing blurred interfaces across enterprise monitors.

### Depth Strategy
- **Layer 0 (Base Canvas)**: `#F8FAFC`. The foundational backdrop for map layers and workspace grids.
- **Layer 1 (Card & Module Surface)**: Pure `#FFFFFF` framed with a subtle 1px border (`#E2E8F0`). Shadow is muted and ambient: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`.
- **Layer 2 (Floating Popovers & Flyout Menus)**: `#FFFFFF` with a 1px border (`#CBD5E1`) and directional shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.07), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`.
- **Layer 3 (Modal Drawers & Dispatch Overlays)**: `#FFFFFF` framed with elevated depth: `0 10px 15px -3px rgba(15, 23, 42, 0.1), 0 4px 6px -4px rgba(15, 23, 42, 0.05)`. Drawers slide strictly from the left or right depending on flow; contextual detail panels slide from the left, honoring the RTL primary entry vector.

## Shapes

The design system employs a refined, professional radius level (`1` / Soft). This keeps interface elements crisp, industrial, and structured—avoiding both raw brutalism and playful, overly-rounded aesthetics.

### Radius Token Scale
- **Base Components (Inputs, Buttons, Badges, Dropdown Items)**: `0.25rem` (4px).
- **Panels, Cards, and Segmented Containers (`rounded-lg`)**: `0.5rem` (8px).
- **Flyout Drawers & Center Dialogs (`rounded-xl`)**: `0.75rem` (12px).
- **Pills (Strictly Status Dots & Count Badges)**: `9999px` fully rounded.

## Components

### Enterprise Data Tables
- **Sticky Headers**: Pinned top headers in `#F1F5F9` with dark slate text (`#1E293B`, `12px`, weight 600) and bottom border (`#E2E8F0`).
- **Row Densities**: Standard 44px height; compact 36px mode for high-density operations.
- **Hover & Selection**: Row background shifts to `#F8FAFC` on hover; selected row features a 3px vertical accent bar positioned along the right edge in primary blue (`#0284C7`) with `#F0F9FF` background tint.
- **RTL Pinned Columns**: The primary vehicle/manifest ID remains pinned to the right edge during horizontal table scroll.

### Status Badges & Indicators
- Compact height (22px), font size `11px`, weight 600, radius `4px`.
- Composed of an inner 6px circular indicator dot paired with localized label (e.g., نشط, متأخر, قيد الانتظار).
- Uses matching semantic pairs: e.g., Delayed badge uses `#FEF2F2` background, `#991B1B` text, and `#EF4444` dot.

### Buttons & Interactive Controls
- **Primary Action**: Solid `#0F172A` background, pure white text, subtle hover lift to `#1E293B`.
- **Secondary Action**: Bordered 1px `#CBD5E1`, surface `#FFFFFF`, text `#1E293B`, hover `#F8FAFC`.
- **Destructive Action**: `#EF4444` surface with white text, or ghost variant with `#EF4444` text.
- **Icon Positioning**: Leading icons sit on the right of the Arabic label; trailing icons (like chevron arrows) sit on the left.

### Sleek Modal Drawers (Flyout Panels)
- Slides in smoothly from the left screen boundary (the secondary side in RTL space) so primary operations remain visible on the right.
- Header holds localized title, telemetry counter, and an explicit dismiss button anchored at the top-left corner.
- Pinned bottom actions container separated by a 1px border (`#E2E8F0`).

### Clean Breadcrumbs & Segmented Tabs
- **Breadcrumbs**: Right-to-left trajectory utilizing an RTL chevron (`‹` instead of `›`). Current item in `#0F172A` (weight 600); ancestor links in `#64748B`.
- **Segmented Tabs**: Contained slate pill track (`#F1F5F9`, 4px padding) with an active white card segment (`#FFFFFF`) featuring hairline shadow, active text in `#0F172A`, and badge counts in neutral slate.

### Inputs & Filters
- Compact border-radius (4px), clear focus ring using `#0284C7` at 2px offset.
- Floating search and filter fields anchor prefix search glyphs on the right margin with placeholder text aligned right.